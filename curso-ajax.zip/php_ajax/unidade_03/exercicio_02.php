<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>PHP com AJAX</title>
    </head>

    <body>

        <script src="jquery.js"></script>
        <script>

        </script>
    </body>
</html>